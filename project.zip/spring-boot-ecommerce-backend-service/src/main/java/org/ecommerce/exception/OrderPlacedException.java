package org.ecommerce.exception;

public class OrderPlacedException extends Exception {

	public OrderPlacedException(String message)
	{
		super(message);
	}
}
