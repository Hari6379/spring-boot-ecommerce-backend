package org.ecommerce.exception;

public class CartDeleteException extends Exception {
	

	public CartDeleteException(String message)
	{
		super(message);
	}
}
