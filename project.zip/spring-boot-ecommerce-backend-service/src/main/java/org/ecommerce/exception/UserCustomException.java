package org.ecommerce.exception;

public class UserCustomException extends Exception {

	public UserCustomException(String message)
	{
		super(message);
	}
}
