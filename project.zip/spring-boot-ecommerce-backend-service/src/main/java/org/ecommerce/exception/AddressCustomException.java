package org.ecommerce.exception;

public class AddressCustomException extends Exception {

	public AddressCustomException(String message)
	{
		super(message);
	}

}
