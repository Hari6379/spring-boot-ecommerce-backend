package org.ecommerce.exception;

public class ProductCustomException extends Exception {
	
	public ProductCustomException(String message)
	{
		super(message);
	}

}
